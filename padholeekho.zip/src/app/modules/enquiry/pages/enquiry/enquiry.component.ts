import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EnquiryService } from '../../services'
import { tap, catchError, finalize } from 'rxjs/operators';
import { of } from 'rxjs';


@Component({
  selector: 'app-enquiry',
  templateUrl: './enquiry.component.html',
  styleUrls: ['./enquiry.component.css']
})
export class EnquiryComponent implements OnInit {
  enquiryForm : FormGroup;
  submitted: boolean = false;
  error: any;
  isLoading: boolean = false;
  message: any;

  constructor ( 
    private formBuilder: FormBuilder,
    private enquiryService: EnquiryService
    
    ) { 
    this.enquiryForm = this.formBuilder.group({
      name: ["", Validators.required ],
      email: ["", [Validators.required, Validators.email]],
      super_course_id: ["", Validators.required ],
      phone: [null, [Validators.required,Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      enquiry: ["", Validators.required ],
      via_phone: [""],
    })
   }

   get f() {
    return this.enquiryForm.controls;
  }

  ngOnInit() {

  }

  enquiry(){
   this.submitted = true;
   if (this.enquiryForm.invalid) {
    return;
  }
  this.isLoading = true;
   console.log(this.enquiryForm.value);

   this.enquiryService.enquiryApi(this.enquiryForm.value).pipe(
     tap(response =>{
       console.log(response)
       this.message = response.response.message;
     }),
     finalize(() => this.isLoading = false),
    catchError(error => of(this.error = error))
   ).subscribe();
   
  }
  
}
