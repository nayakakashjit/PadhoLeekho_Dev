import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './pages/home/home.component'; 
import { DetailsComponent } from './pages/details/details.component';

const routes: Routes = [  
  {
    path: '',
    component: HomeComponent
  } ,
  {
    path: 'details',
    component: DetailsComponent
  },
  
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  }, 
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class HomeRoutingModule { }
