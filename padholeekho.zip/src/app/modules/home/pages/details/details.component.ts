import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router'
import { DetailsService } from '../../services/details/details.service';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { HomeService } from '../../services/home/home.service';
import { AuthService } from 'src/app/core/services/auth/auth.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  isLoading: boolean = false;
  error: any;
  courseDetails: any;
  student_Also_Brought: any;
  conceptually_Interrelated_Courses: any;
  combo_offer: any;
  alertMsg: { class: string; text: any; info: string };
  message: any;


  constructor(
    private ActivatedRoute: ActivatedRoute,
    private detailsServive: DetailsService,
    private homeService: HomeService,
    private authService: AuthService,
    private router: Router,
  ) {
    this.ActivatedRoute.params.subscribe((params) => {
      if (params["id"]) {
        this.isLoading = true;
        this.detailsServive.courseCodeApi(params["id"])
          .pipe(
            tap((response) => {
              this.courseDetails = response.data
            }),
            finalize(() => (this.isLoading = false)),
            catchError(error => of(this.error = error)),
          ).subscribe();

        /* student Also Brought */
        this.studentAlsoBrought(params["id"])
        /* conceptually Interrelated Courses */
        this.conceptuallyInterrelatedCourses(params["id"])
        /* combo Offer */
        this.comboOffer()
      }
    })
  }

  ngOnInit() {

  }

  /* student Also Brought */
  studentAlsoBrought(id) {
    this.detailsServive.studentAlsoBroughtApi(id)
      .pipe(
        tap((response) => {
          this.student_Also_Brought = response.data
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of(this.error = error)),
      ).subscribe()
  }

  /* conceptually Interrelated Courses */
  conceptuallyInterrelatedCourses(id) {
    this.detailsServive.conceptuallyInterrelatedCoursesApi(id)
      .pipe(
        tap((response) => {
          this.conceptually_Interrelated_Courses = response.data
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of(this.error = error)),
      ).subscribe()
  }

  /* Combo Offer */
  comboOffer() {
    this.homeService.comboOfferApi()
      .pipe(
        tap(response => {
          this.combo_offer = response.data
        }),
        finalize(() => this.isLoading = false),
        catchError(error => of(this.error = error))
      ).subscribe()
  }

  /* Add to wish List*/
  storetoWishlist(entity_type, entity_id) {
    this.isLoading = true;
    let storetoWishlistParam = {
      user_id: localStorage.getItem("user_Id"),
      entity_type: entity_type,
      entity_id: entity_id
    };
    this.detailsServive.storetoWishlistApi(storetoWishlistParam)
      .pipe(
        tap(response => {
          this.message = response.response.message;
          if (response.status == "success" || response.status == "failure") {
            this.alertMsg = {
              class: "received",
              text: response.response.message,
              info: "Success"
            };
          }
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of((this.error = error)))
      )
      .subscribe();
  }

  /*  Add To Cart */

  addToCart(entity_type, entity_id) {
    if (this.authService.isSession()) {
      this.isLoading = true;
      let addtocartParam = {
        user_id: localStorage.getItem("user_Id"),
        entity_id: entity_id,
        entity_type: entity_type
      };
      this.detailsServive.addToCartApi(addtocartParam).pipe(
        tap(response => {
          this.message = response.response.message;
          if (response.status == "success" || response.status == "failure") {
            this.alertMsg = {
              class: "received",
              text: response.response.message,
              info: "Success"
            };
          }
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of((this.error = error)))
      )
        .subscribe();
    } else {
      this.router.navigate(["auth/login"]);
    }
  }

  // Student Also Brought
  sab: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [
      '<i class="fa fa-angle-left"></i>',
      '<i class="fa fa-angle-right"></i>'
    ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 3
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      }
    },
    nav: true
  };

  // Conceptually Interrelated Courses
  cic: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [
      '<i class="fa fa-angle-left"></i>',
      '<i class="fa fa-angle-right"></i>'
    ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 3
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      }
    },
    nav: true
  };

  // Combo Offer
  ComboOfferSlide: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [
      '<i class="fa fa-angle-left"></i>',
      '<i class="fa fa-angle-right"></i>'
    ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      }
    },
    nav: true
  };

}
