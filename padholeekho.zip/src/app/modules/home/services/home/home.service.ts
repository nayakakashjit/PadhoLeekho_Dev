import { Injectable } from '@angular/core';
import { ApiService } from '../../../../core/services';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor( private apiService: ApiService ) {}

  bannerApi(){
    return this.apiService.get('/api/admin/content-setting/list', {type:'banner'})
  }

  recentCoursesApi(){
    return this.apiService.get('/api/rest/courses/listing/recent-course', "")
  }

  comboOfferApi(){
    return this.apiService.get('/api/rest/courses/listing/combo-offer', "")
  }

  section_4_Api(){
    return this.apiService.get('/api/admin/content-setting/list', "")
  }

  upcomingCoursesApi(){
    return this.apiService.get('/api/admin/course/upcoming-course/list', {status:'active'})
  }

  freeLessonApi(data){
    return this.apiService.post('/api/admin/free-lesson/store', data)
  }

  addToCartApi(data){
    return this.apiService.post('/api/rest/cart/store', data)
  }

}
