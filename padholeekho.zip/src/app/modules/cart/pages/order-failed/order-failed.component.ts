import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-failed',
  templateUrl: './order-failed.component.html',
  styleUrls: ['./order-failed.component.css']
})
export class OrderFailedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
