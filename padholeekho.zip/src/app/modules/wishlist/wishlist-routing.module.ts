import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { WishlistComponent } from '../wishlist'
import { EmptyWishlistComponent } from './pages/empty-wishlist/empty-wishlist.component';


const routes: Routes = [  
  {
    path: '',
    component: WishlistComponent,
  },
  {
    path: 'emptyWishList',
    component: EmptyWishlistComponent,
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  }, 
];
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class WishlistRoutingModule { }
