import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-empty-wishlist',
  templateUrl: './empty-wishlist.component.html',
  styleUrls: ['./empty-wishlist.component.css']
})
export class EmptyWishlistComponent implements OnInit {

  constructor(private router:Router) { }

  goRegister(){
    this.router.navigate(['auth/register']);
  }

  goLogin(){
    this.router.navigate(['auth/login'])
  }

  ngOnInit() {
  }

}
