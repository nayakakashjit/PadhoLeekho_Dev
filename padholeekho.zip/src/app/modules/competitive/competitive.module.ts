import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompettitiveRoutingModule } from './compettitive-routing.module';
import { CatComponent } from './pages/cat/cat.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms'
import { CarouselModule } from 'ngx-owl-carousel-o';
import { DetailsComponent } from './pages/details/details.component';
import { RatingModule } from 'ng-starrating';
import { MatVideoModule } from 'mat-video';



@NgModule({
  declarations: [CatComponent, DetailsComponent],
  imports: [
    CommonModule,
    CompettitiveRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    CarouselModule,
    RatingModule,
    MatVideoModule
  ]
})
export class CompetitiveModule { }
