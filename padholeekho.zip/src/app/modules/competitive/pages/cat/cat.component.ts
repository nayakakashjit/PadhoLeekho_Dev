import { Component, OnInit } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { Router, ActivatedRoute } from "@angular/router";
import { ApiService, AuthService } from "../../../../core/services";
import { tap, catchError, finalize } from "rxjs/operators";
import { of } from "rxjs";
import { CompetitiveService } from "src/app/modules/competitive/services/competitive.service";
import { HomeService } from "src/app/modules/home/services/home/home.service";
import { SupportService } from "src/app/modules/support/services";

@Component({
  selector: "app-cat",
  templateUrl: "./cat.component.html",
  styleUrls: ["./cat.component.css"]
})
export class CatComponent implements OnInit {
  homeForm: FormGroup;
  submitted = false;
  isLoading: boolean = false;
  menuId: any;
  error: any;
  data: any;
  tablist: any[];
  tabdata: any[];
  response: any;
  sectionTwo_data: any[];
  sectionTwo_data_res: any;
  dropDownList: any[];
  alertMsg: { class: string; text: any; info: string };
  message: any;
  isShown: boolean = false;
  isShownOne: boolean = true;
  subcourse: any;
  condition: any;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private apiservice: ApiService,
    private authService: AuthService,
    private competitiveService: CompetitiveService,
    private homeService: HomeService,
    private supportService: SupportService
  ) {
    this.homeForm = this.formBuilder.group({
      name: ["", Validators.required],
      email: ["", [Validators.required, Validators.email]],
      phone: [
        null,
        [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]
      ],
      super_course_id: ["", Validators.required]
    });

    this.activatedRoute.params.subscribe(params => {
      if (params["id"]) {
        this.isLoading = true;
        this.competitiveService
          .superCourseApi(params["id"])
          .pipe(
            tap(response => {
              const data = Array.from(
                Object.keys(response.data),
                k => response.data[k]
              );
              this.data = data[0];
            }),
            finalize(() => (this.isLoading = false)),
            catchError(error => of((this.error = error)))
          )
          .subscribe();
      }
    });
  }

  get f() {
    return this.homeForm.controls;
  }

  submitFreeLesonForm() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.homeForm.invalid) {
      return;
    }

    this.isLoading = true;
    this.homeService
      .freeLessonApi(this.homeForm.value)
      .pipe(
        tap(response => {
          if (response.status == "success" || response.status == "failure") {
            this.alertMsg = {
              class: "received",
              text: response.response.message,
              info: "Success"
            };
          }
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of((this.error = error)))
      )
      .subscribe();
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.isLoading = true;
      if (params["id"]) {
        this.competitiveService.masterCourseListApi(params["id"]).pipe(
            tap(response => {
              this.tablist = Array.from(
                Object.keys(response.data),
                k => response.data[k]
              );
              this.tabDetails(this.tablist[0].id, this.tablist[0].name);
            }),
            finalize(() => (this.isLoading = false)),
            catchError(error => of((this.error = error)))
          )
          .subscribe();
      }
    });

    // Free Lessoin Dropwown List

    this.supportService
      .preparationDropdownApi()
      .pipe(
        tap(response => {
          this.dropDownList = Array.from(
            Object.keys(response.data),
            k => response.data[k]
          );
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of((this.error = error)))
      )
      .subscribe();
  }

  // Sub Course Api

  subCourse(id) {
    this.isLoading = true;
    this.competitiveService.subCourseApi(id)
      .pipe(
        tap(response => {
          if (response.status == "success") {
            this.subcourse = response.data;
            this.toggleShow();

            if (this.subcourse.length < 3) {
              let count = 3;
              let iterate = count - this.subcourse.length;
              for (let i = 0; i < iterate; i++) {
                this.subcourse.push({
                  title: "Coming Soon",
                  course_code: "",
                  image: "assets/Images/Global/comingSoon_350x250.jpg",
                  description: null,
                  max_rating: "0.0",
                  rating: "0.0",
                  actual_price: "0",
                  discount_price: 0,
                  final_price: 0,
                  offer: 0,
                  entity_type: "",
                  entity_id: 0,
                  type: "ComingSoon"
                });
              }
            }
          }
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of((this.error = error)))
      )
      .subscribe();
  }

  tabDetails(id, itemName) {
    // First Section
    this.condition = itemName;
    this.isLoading = true;
    this.competitiveService.tabDetailsApi(id)
      .pipe(
        tap(response => {
          this.response = response.status;
          const tabdata = Array.from(
            Object.keys(response.data),
            k => response.data[k]
          );
          this.tabdata = tabdata[0];
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of((this.error = error)))
      )
      .subscribe();

    // Second Section

    this.isLoading = true;
    this.competitiveService.courseListApi(id)
      .pipe(
        tap(response => {
          this.sectionTwo_data_res = response.status;
          this.sectionTwo_data = Array.from(
            Object.keys(response.data),
            k => response.data[k]
          );
          if (this.sectionTwo_data.length < 3) {
            let count = 3;
            let iterate = count - this.sectionTwo_data.length;
            for (let i = 0; i < iterate; i++) {
              this.sectionTwo_data.push({
                title: "Coming Soon",
                course_code: "",
                image: "assets/Images/Global/comingSoon_350x250.jpg",
                description: null,
                max_rating: "0.0",
                rating: "0.0",
                actual_price: "0",
                discount_price: 0,
                final_price: 0,
                offer: 0,
                entity_type: "",
                entity_id: 0,
                type: "ComingSoon"
              });
            }
          }
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of((this.error = error)))
      )
      .subscribe();
  }

  courseDetails(pageName, id) {
    //  this.router.navigate(['details', {id:id}])
    this.authService.isSession()
      ? this.router.navigate([`user/competitive/${pageName}`, { id: id }])
      : this.router.navigate([`auth/competitive/${pageName}`, { id: id }]);
  }

  // Add To Cart

  addToCart(entity_type, entity_id) {
    if (this.authService.isSession()) {
      this.isLoading = true;
      let addtocartParam = {
        user_id: localStorage.getItem("user_Id"),
        entity_id: entity_id,
        entity_type: entity_type
      };
      this.competitiveService.addToCartApi(addtocartParam)
        .pipe(
          tap(response => {
            this.message = response.response.message;
            if (response.status == "success" || response.status == "failure") {
              this.alertMsg = {
                class: "received",
                text: response.response.message,
                info: "Success"
              };
            }
          }),
          finalize(() => (this.isLoading = false)),
          catchError(error => of((this.error = error)))
        )
        .subscribe();
    } else {
      this.router.navigate(["auth/login"]);
    }
  }

  // Book Now

  bookNow(entity_type, entity_id, ActualPrice, DiscountPrice, FinalPrice) {
    if (this.authService.isSession()) {
      this.isLoading = true;
      let bookNowParam = {
        user_id: localStorage.getItem("user_Id"),
        entity_id: entity_id,
        entity_type: entity_type,
        booking_type: "book_now",
        actual_price: ActualPrice,
        discount_price: DiscountPrice,
        final_price: FinalPrice
      };
      this.competitiveService.bookNowApi(bookNowParam)
        .pipe(
          tap(response => {
            console.log(response);
          }),
          finalize(() => (this.isLoading = false)),
          catchError(error => of((this.error = error)))
        )
        .subscribe();
    } else {
      this.router.navigate(["auth/login"]);
    }
  }

  toggleShow() {
    this.isShown = true;
    this.isShownOne = false;
  }
  back() {
    this.isShown = false;
    this.isShownOne = true;
  }

  callError(error) {
    this.alertMsg = {
      class: "received",
      text: this.message,
      info: "Alert"
      // "colorClass": "message-danger"
    };
  }

  // course List Slider
  courseList: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [
      '<i class="fa fa-angle-left"></i>',
      '<i class="fa fa-angle-right"></i>'
    ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      },
      1024: {
        items: 5
      }
    },
    nav: true
  };

  // Sab Course List Slider
  subcourseList: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [
      '<i class="fa fa-angle-left"></i>',
      '<i class="fa fa-angle-right"></i>'
    ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      },
      1024: {
        items: 5
      }
    },
    nav: true
  };
}
