import { Injectable } from "@angular/core";
import { ApiService } from "src/app/core/services";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class CompetitiveService {
  constructor(private apiservice: ApiService) { }

  competitiveExamApi(menuid): Observable<any> {
    return this.apiservice.get(
      "/api/rest/courses/listing/super-course",
      menuid
    );
  }

  masterCourseListApi(id): Observable<any> {
    return this.apiservice.get("/api/admin/course/level-setting/master-course/list", { super_course_id: id })
  }

  superCourseApi(id): Observable<any> {
    return this.apiservice.get("/api/rest/courses/listing/super-course", { id: id })
  }

  subCourseApi(id): Observable<any> {
    return this.apiservice.get("/api/rest/courses/listing/sub-course", { course_id: id })
  }

  tabDetailsApi(id): Observable<any> {
    return this.apiservice.get("/api/rest/courses/listing/master-course", { id: id })
  }

  courseListApi(id): Observable<any> {
    return this.apiservice.get("/api/rest/courses/listing/course", { master_course_id: id })
  }

  addToCartApi(addtocartParam): Observable<any> {
    return this.apiservice.post("/api/rest/cart/store", addtocartParam)
  }

  bookNowApi(bookNowParam): Observable<any> {
    return this.apiservice.post("/api/rest/booking/temporary-booking", bookNowParam)
  }

  /* Competitive Details Page API Start */



}
