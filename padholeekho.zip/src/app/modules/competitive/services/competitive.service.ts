import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/core/services';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CompetitiveService {

  constructor(private apiservice: ApiService) { }

  competitiveExamApi(menuid): Observable<any>{
    return this.apiservice.get('/api/rest/courses/listing/super-course', menuid)
  }

}
