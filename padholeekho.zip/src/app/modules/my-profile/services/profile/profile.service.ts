import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from '../../../../core/services';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  constructor( private apiservices: ApiService ) { }

  myprofileApi(data):Observable<any> {
    return this.apiservices.get('/api/rest/authentication/signin/profile', data)
  }
}
