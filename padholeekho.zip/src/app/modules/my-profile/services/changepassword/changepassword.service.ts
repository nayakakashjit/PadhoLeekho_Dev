import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/core/services';

@Injectable({
  providedIn: 'root'
})
export class ChangepasswordService {

  constructor( private apiservices: ApiService ) { };

    // Change Password API -------------------------------------!

    changepasswordApi(data):Observable<any>{
      console.log(data);
      return this.apiservices.post('/api/rest/authentication/password/change', data)
    }
}
