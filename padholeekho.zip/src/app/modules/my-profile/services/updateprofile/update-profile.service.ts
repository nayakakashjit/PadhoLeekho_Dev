import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/core/services';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UpdateProfileService {

  constructor(private apiservices: ApiService) { } 

  // Update Profile API -------------------------------------!

  updateprofileApi(data):Observable<any>{
    return this.apiservices.post('/api/rest/authentication/signin/profile', data)
  }

  myprofileApi(userId):Observable<any> {
    return this.apiservices.get('/api/rest/authentication/signin/profile', {user_id:userId} )
  } 
}
