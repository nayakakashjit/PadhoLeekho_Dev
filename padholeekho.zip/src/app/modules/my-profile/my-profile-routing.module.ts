import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { MyProfileComponent } from './pages/my-profile/my-profile.component';
import { ChangePasswordComponent } from './pages/change-password/change-password.component';
import { UpdateProfileComponent } from './pages/update-profile/update-profile.component';


const routes: Routes = [  
  {
    path: '',
    component: MyProfileComponent
  } ,
  {
    path: 'changePassword',
    component: ChangePasswordComponent
  },
  {
    path: 'updateProfile',
    component: UpdateProfileComponent
  },
  {
    path: 'footer',
    component: MyProfileComponent
  } ,
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  }, 
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ] 
})
export class MyProfileRoutingModule { }
