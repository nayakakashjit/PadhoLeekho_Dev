import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ChangepasswordService } from '../../services/changepassword/changepassword.service';
import { finalize, tap, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  changePasswordForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean;
  error: any;



  constructor( 
    private formBuilder: FormBuilder,
    private router: Router,
    private changepasswordservice: ChangepasswordService
    ) {
    this.changePasswordForm = this.formBuilder.group({
      old_password: ["", [Validators.required, Validators.minLength(6)]],
      password:     ["", [Validators.required, Validators.minLength(6)]],
    })
   }

  ngOnInit() {
    
  }
  // convenience getter for easy access to form fields
  get f() { return this.changePasswordForm.controls; }

  changePassword(){
    let changePasswordParams = {
      user_id: localStorage.getItem('user_Id'),
      password: this.changePasswordForm.value.password,
      old_password: this.changePasswordForm.value.old_password,
    };
    console.log(changePasswordParams);
    this.submitted = true;
    // stop here if form is invalid
    if (this.changePasswordForm.invalid) {
        return;
    }
    this.changepasswordservice.changepasswordApi(changePasswordParams).pipe(
      tap(response =>{
        console.log(response)
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  };

  goRegister() {
    this.router.navigate(['register']);
  }

}
