import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  changePasswordForm: FormGroup;
  submitted: boolean = false;

  constructor( 
    private formBuilder: FormBuilder,
    ) {
    this.changePasswordForm = this.formBuilder.group({
      old_password: ["", [Validators.required, Validators.minLength(6)]],
      password:     ["", [Validators.required, Validators.minLength(6)]]
    })
   }

  ngOnInit() {
    
  }
  // convenience getter for easy access to form fields
  get f() { return this.changePasswordForm.controls; }

  changePassword(){
    this.submitted = true;

    // stop here if form is invalid
    if (this.changePasswordForm.invalid) {
        return;
    }
  };

}
