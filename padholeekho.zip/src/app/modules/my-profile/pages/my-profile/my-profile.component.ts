import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../../services'
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {
  isLoading: boolean;
  error: any;

  constructor( private profileServices: ProfileService ) { }

  ngOnInit() {
    let user_id = localStorage.getItem('user_Id');
    this.profileServices.myprofileApi(user_id).pipe(
      tap(response =>{
        console.log(response)
      }),
      finalize(() => this.isLoading = false),
    catchError(error => of(this.error = error))
    ).subscribe();
  }

}
