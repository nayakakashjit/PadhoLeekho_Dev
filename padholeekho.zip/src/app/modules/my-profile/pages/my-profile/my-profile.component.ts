import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../../services'
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {
  isLoading: boolean;
  error: any;

  constructor( private profileServices: ProfileService ) { }

  ngOnInit() {
    this.profileServices.myprofileApi(3).pipe(
      tap(response =>{
        console.log(response)
      }),
      finalize(() => this.isLoading = false),
    catchError(error => of(this.error = error))
    ).subscribe();
  }

}
