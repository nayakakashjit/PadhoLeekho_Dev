import { Component, OnInit } from "@angular/core";
import { ProfileService } from "../../services";
import { tap, finalize, catchError } from "rxjs/operators";
import { of } from "rxjs";
import { Router } from "@angular/router";

@Component({
  selector: "app-my-profile",
  templateUrl: "./my-profile.component.html",
  styleUrls: ["./my-profile.component.css"]
})
export class MyProfileComponent implements OnInit {
  isLoading: boolean = false;
  error: any;
  userinfo: any;
  enquiryList: any;
  supportList: any;
  bookorderlists: any;
  topicOrderLists: any;

  constructor(private profileServices: ProfileService, private router: Router) {
    this.userProfile();
    this.enquiryRequestlist();
    this.supportRequestlist();
    this.bookedOrderList();
  }

  ngOnInit() {}

  // User Profile

  userProfile() {
    let userId = localStorage.getItem("user_Id");
    this.isLoading = true;
    this.profileServices
      .myprofileApi(userId)
      .pipe(
        tap(response => {
          this.userinfo = response.data;
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of((this.error = error)))
      )
      .subscribe();
  }

  // Enquire Request List

  enquiryRequestlist() {
    let userId = localStorage.getItem("user_Id");
    this.isLoading = true;
    this.profileServices
      .enquiryRequestlistApi(userId)
      .pipe(
        tap(response => {
          this.enquiryList = response.data;
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of((this.error = error)))
      )
      .subscribe();
  }

  // Support Request List

  supportRequestlist() {
    let userId = localStorage.getItem("user_Id");
    this.isLoading = true;
    this.profileServices
      .supportRequestlistApi(userId)
      .pipe(
        tap(response => {
          this.supportList = response.data;
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of((this.error = error)))
      )
      .subscribe();
  }

  bookedOrderList() {
    let userId = localStorage.getItem("user_Id");
    this.isLoading = true;
    this.profileServices
      .bookedOrderListApi(userId)
      .pipe(
        tap(response => {
          this.bookorderlists = response.data;
        }),
        finalize(() => (this.isLoading = false)),
        catchError(error => of((this.error = error)))
      )
      .subscribe();
  }

  bookedTopicList(entity_type, entity_id) {
    let topicListParams = { entity_type: entity_type, entity_id: entity_id };
    this.isLoading = true;
    this.profileServices
      .topicOrderListApi(topicListParams)
      .pipe(
        tap(response => {
          this.topicOrderLists = response.data;
        }),
        finalize(() => {this.isLoading = false}),
        catchError(error => of((this.error = error)))
      )
      .subscribe();
  }

  courseDetails(id) { 
    this.router.navigate(['user/myProfile/courseDetails', { id: id }]);
  }


  changePassword() {
    this.router.navigate(["user/myProfile/changePassword"]);
  }
  updateProfile() {
    this.router.navigate(["user/myProfile/updateProfile"]);
  }

    // Topic List
    topicListSlide: any = {
      loop: true,
      mouseDrag: true,
      touchDrag: true,
      pullDrag: false,
      dots: false,
      navSpeed: 700,
      navText: [
        '<i class="fa fa-angle-left"></i>',
        '<i class="fa fa-angle-right"></i>'
      ],
      responsive: {
        0: {
          items: 1
        },
        400: {
          items: 2
        },
        740: {
          items: 3
        },
        940: {
          items: 5
        }
      },
      nav: true
    };
}


