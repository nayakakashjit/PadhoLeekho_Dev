import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyProfileRoutingModule } from './my-profile-routing.module';
import { MyProfileComponent } from './pages/my-profile/my-profile.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ChangePasswordComponent } from './pages/change-password/change-password.component';
import { UpdateProfileComponent } from './pages/update-profile/update-profile.component';

@NgModule({
  declarations: [MyProfileComponent, ChangePasswordComponent, UpdateProfileComponent],
  imports: [
    CommonModule,
    MyProfileRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class MyProfileModule { }
