/* ......All user profile Export Features....... */
export * from './pages/my-profile/my-profile.component';

export * from './pages/change-password/change-password.component';

export * from './pages/update-profile/update-profile.component';

export * from './pages/course-details/course-details.component';