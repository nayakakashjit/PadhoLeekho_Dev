import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProfileService } from 'src/app/modules/my-profile/services';
import { tap, catchError } from 'rxjs/operators';
import { ApiService } from 'src/app/core/services';
import { of } from 'rxjs';
declare let $: any;

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  toggleValue: boolean = false;
  username: any;
  menudata = [];
  error: any;
  dropDown: boolean = false;

  constructor(
    private router: Router,
    private profileServices: ProfileService,
    private apiservice: ApiService,
  ) {
    $(document).ready(function () {
      $(document).click(function (event) { 
        var clickover = $(event.target);   
        var _opened = $(".exo-menu").hasClass("display");
        if (_opened === true && !clickover.hasClass("span-toggle")) { 
          $('.exo-menu').removeClass("display");
          $('.nav-toggle').removeClass("active");
        }
      });
    });
  }

  goDetailsPage(id) {
    this.router.navigate(['user/competitive/cat', { id: id }]);
  }

  ngOnInit() {
    // For user name In header
    let userId = localStorage.getItem('user_Id')
    this.profileServices.myprofileApi(userId).pipe(
      tap(response => {
        this.username = response.data.name;
      }),
    ).subscribe();

    // Competitive Exam Menu 
    this.apiservice.get('/api/admin/course/level-setting/super-course/list', {status:'active'}).pipe(
      tap(response => {
        this.menudata = Array.from(Object.keys(response.data), k => response.data[k]);
      }),
      catchError(error => of(this.error = error))
    ).subscribe()
  }

  toggle() {
    this.toggleValue = !this.toggleValue ? true : false;
  }

  logout() {
    localStorage.removeItem('user_Id');
    this.router.navigate(['auth/home']);
  }

  changIcon() {
    this.dropDown = this.dropDown ? false : true;
  }

}
