/* .....Footer..............*/

export * from './footer/footer.component';

/* ......Header............ */

export * from './header/header.component';

/* ......Nav................*/

export * from './nav/nav.component';

/* ......Testimonial........*/

export * from './testimonial/testimonial.component';

/* ......Download...........*/

export * from './download/download.component';

/* ......Module Route........*/

export * from './moduleRoute/moduleRoute';

/* ......Password Match......*/

export * from './directive/match'; 




