import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit { 
  _alertMsg: {
    "class": "",
    "text": "",
    "info": ""
  };
  @Input()
  set alertMsg(alertValue) {  
    this._alertMsg = alertValue;  
  }
  constructor() { }

  ngOnInit() {
  }

  dismiss() {
    this._alertMsg['class'] = "";
  }

}
