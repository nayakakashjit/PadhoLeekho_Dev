import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/services';
import { tap, catchError } from 'rxjs/operators';
import { of } from 'rxjs';


@Component({
  selector: 'app-testimonial',
  templateUrl: './testimonial.component.html',
  styleUrls: ['./testimonial.component.css']
})
export class TestimonialComponent implements OnInit {
  error: any;
  constructor( private apiservice: ApiService ) { }

  ngOnInit() {
    // Testimial 
    this.apiservice.get('/api/admin/content-setting/list', 'testimonials').pipe(
      tap(response=>{
        // console.log(response)
      }),
     catchError(error => of(this.error = error))
    ).subscribe()

    // Blog
    this.apiservice.get('/api/admin/content-setting/list', 'blog').pipe(
      tap(response=>{
        // console.log(response)
      }),
     catchError(error => of(this.error = error))
    ).subscribe()
  }

  //Testimonial Slider
  testimonial: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 2
      },
      940: {
        items: 2
      }
    },
    nav: true
  }

  //Blog Slider
  blog: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 2
      }
    },
    nav: true
  }

}
