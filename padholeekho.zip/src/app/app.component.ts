import { Component, HostListener } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter, take } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  isLoading = true;

// Prevent Right Click
  @HostListener('contextmenu', ['$event'])
  onRightClick(event) {
    event.preventDefault();
  }

  constructor(private router: Router) {
    router.events.pipe(filter(e => e instanceof NavigationEnd, take(1))).subscribe((e) => {
      this.isLoading = false;
    });
  }

}
