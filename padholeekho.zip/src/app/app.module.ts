import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';  
import { HeaderComponent, FooterComponent, NavComponent, DetailsComponent, PnfComponent } from './shared'; 
import { HttpClientModule } from '@angular/common/http';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';  
import { AuthGuard } from './core';  
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { RatingModule } from 'ng-starrating';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { SharedModule } from './shared/shared.module'; 
import { MatVideoModule } from 'mat-video';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavComponent,
    DetailsComponent,
    PnfComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    FormsModule,
    RatingModule,
    CarouselModule,
    SharedModule,
    MatVideoModule
  ],   
  providers: [{provide: LocationStrategy, useClass: HashLocationStrategy},AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
