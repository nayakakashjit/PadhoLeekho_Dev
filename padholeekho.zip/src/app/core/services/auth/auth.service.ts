import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  isSession() { 
    return localStorage.getItem('user_Id') ? true : false;
  }

}
