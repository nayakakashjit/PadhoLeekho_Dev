import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { CartComponent, EmptyCartComponent } from '../cart'; 
import { OrderSuccessComponent } from './pages/order-success/order-success.component';
import { OrderFailedComponent } from './pages/order-failed/order-failed.component';

const routes: Routes = [  
  {
    path: '',
    component: CartComponent,
  },
  {
    path: 'emptyCart',
    component: EmptyCartComponent,
  },
  {
    path: 'orderSuccess',
    component: OrderSuccessComponent
  },
  {
    path: 'orderFailed',
    component: OrderFailedComponent
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  }, 
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class CartRoutingModule { }
