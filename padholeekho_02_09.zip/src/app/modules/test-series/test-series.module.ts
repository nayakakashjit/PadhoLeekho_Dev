import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { TestSeriesRoutingModule } from "./test-series-routing.module";
import { SharedModule } from "src/app/shared/shared.module";
import { OnlineTestSeriesComponent } from "./pages/online-test-series/online-test-series.component";
import { SeriesListComponent } from "./pages/series-list/series-list.component";
import { TestSeriesLoginComponent } from "./pages/test-series-login/test-series-login.component";
import { PurchaseTestSeriesComponent } from './pages/purchase-test-series/purchase-test-series.component';

@NgModule({
  declarations: [
    OnlineTestSeriesComponent,
    SeriesListComponent,
    TestSeriesLoginComponent,
    PurchaseTestSeriesComponent,
  ],
  imports: [
    CommonModule,
    TestSeriesRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    SharedModule,
  ],
})
export class TestSeriesModule {}
