import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-series-list',
  templateUrl: './series-list.component.html',
  styleUrls: ['./series-list.component.css']
})
export class SeriesListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
