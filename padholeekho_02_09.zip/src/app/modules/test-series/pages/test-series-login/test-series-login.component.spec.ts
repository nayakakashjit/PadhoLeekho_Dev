import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestSeriesLoginComponent } from './test-series-login.component';

describe('TestSeriesLoginComponent', () => {
  let component: TestSeriesLoginComponent;
  let fixture: ComponentFixture<TestSeriesLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestSeriesLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestSeriesLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
