import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { OnlineTestSeriesComponent } from './pages/online-test-series/online-test-series.component';
import { SeriesListComponent } from './pages/series-list/series-list.component';
import { TestSeriesLoginComponent } from './pages/test-series-login/test-series-login.component';
import { PurchaseTestSeriesComponent } from './pages/purchase-test-series/purchase-test-series.component';

const routes: Routes = [
  {
    path:'',
    component:TestSeriesLoginComponent
  },
  {
    path:'OnlineTestSeries',
    component: OnlineTestSeriesComponent
  },
  {
    path:'SeriesList',
    component: SeriesListComponent
  },
  {
    path:'PurchaseTestSeries',
    component: PurchaseTestSeriesComponent
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  },
];

@NgModule({
  declarations: [], 
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  // exports: [RouterModule]
})
export class TestSeriesRoutingModule { }
