import { Component, OnInit } from "@angular/core";
import { LoginService } from "../../services";
import { tap, map, finalize, catchError } from "rxjs/operators";
import { of, throwError, from } from "rxjs";
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
} from "@angular/forms";
import { Router } from "@angular/router";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean = false;
  error: any;
  errorMsg: any;
  message: any;
  alertMsg: { class: string; text: string; info: string };

  constructor(
    private loginService: LoginService,
    private formBuilder: FormBuilder,
    private router: Router
  ) {
    this.loginForm = this.formBuilder.group({
      emailphone: [
        null,
        Validators.compose([
          Validators.required,
          Validators.pattern(
            /^(\d{10}|\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3}))$/
          ),
        ]),
      ],
      password: ["", [Validators.required, Validators.minLength(6)]],
    });
  }

  get f() {
    return this.loginForm.controls;
  }

  ngOnInit() {}

  login() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.isLoading = true;
    this.loginService
      .loginApi(this.loginForm.value)
      .pipe(
        tap((response) => {
          this.message = response.response.message;
          if (response.status == "success") {
            localStorage.setItem("user_Id", response.data.user_id); // Storing user id for profile details
            this.router.navigate(["user/home"]);
          } else {
            this.alertMsg = {
              class: "received",
              text: response.response.message,
              info: "Success",
              // "colorClass": "message-success"
            };
          }
        }),
        finalize(() => (this.isLoading = false)),
        catchError((error) => of(this.callError(error)))
      )
      .subscribe();
  }

  callError(error) {
    this.alertMsg = {
      class: "received",
      text: this.message,
      info: "Alert",
      // "colorClass": "message-danger"
    };
  }

  goRegister() {
    this.router.navigate(["auth/register"]);
  }
  forgetpassword() {
    this.router.navigate(["auth/login/forgetPassword"]);
  }
}
