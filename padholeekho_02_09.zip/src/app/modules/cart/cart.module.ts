import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CartComponent } from './pages/cart/cart.component';
import { CartRoutingModule } from './cart-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { EmptyCartComponent } from './pages/empty-cart/empty-cart.component';
import { OrderSuccessComponent } from './pages/order-success/order-success.component';
import { OrderFailedComponent } from './pages/order-failed/order-failed.component';

@NgModule({
  declarations: [CartComponent, EmptyCartComponent, OrderSuccessComponent, OrderFailedComponent],
  imports: [
    CommonModule,
    CartRoutingModule,
    SharedModule
  ]
})
export class CartModule { }
