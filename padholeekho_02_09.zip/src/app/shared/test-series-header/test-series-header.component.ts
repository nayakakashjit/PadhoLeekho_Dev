import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-series-header',
  templateUrl: './test-series-header.component.html',
  styleUrls: ['./test-series-header.component.css']
})
export class TestSeriesHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
