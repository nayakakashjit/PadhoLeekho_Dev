import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/core/services';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SupportService {

  constructor( private apiservice:ApiService ) { }
  supportApi(data): Observable<any> {
    return this.apiservice.post('/api/admin/support/store', data)
  }
  preparationDropdownApi(): Observable<any>{
    return this.apiservice.get('/api/admin/course/level-setting/super-course/list', {status:'active'})
  }
}
