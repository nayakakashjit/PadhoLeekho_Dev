import { Component, OnInit } from '@angular/core'; 
import { AuthService } from '../../core';
@Component({
  selector: 'app-pnf',
  templateUrl: './pnf.component.html',
  styleUrls: ['./pnf.component.css']
})
export class PnfComponent implements OnInit {
  show:boolean;
  constructor(private authService: AuthService) { 
    this.show = this.authService.isSession();
  }

  ngOnInit() {
   
  }

}
