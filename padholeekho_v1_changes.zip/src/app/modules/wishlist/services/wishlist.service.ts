import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/core/services';

@Injectable({
  providedIn: 'root'
})
export class WishlistService {

  constructor(private apiservice:ApiService) { }

  getwistListApi(data){
    return this.apiservice.get('/api/rest/wishlist/list', data)
  }

  movetoCartApi(data){
    return this.apiservice.post('/api/rest/wishlist/move-to-cart', data)
  }

  removeWishListApi(data){
    return this.apiservice.post('/api/rest/wishlist/remove', data)
  }

}
