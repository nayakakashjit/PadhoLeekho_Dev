import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TestSeriesRoutingModule } from './test-series-routing.module';
import { OnlineTestSeriesComponent } from './pages/online-test-series/online-test-series.component';
import { SeriesListComponent } from './pages/series-list/series-list.component';

@NgModule({
  declarations: [OnlineTestSeriesComponent, SeriesListComponent],
  imports: [
    CommonModule,
    TestSeriesRoutingModule
  ]
})
export class TestSeriesModule { }
