import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/core/services';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  constructor( private apiservices: ApiService ) { }

  // Profile Details API -------------------------------------!

  myprofileApi(userId):Observable<any> {
    return this.apiservices.get('/api/rest/authentication/signin/profile', {user_id:userId})
  }

  enquiryRequestlistApi(userId){
    return this.apiservices.get('/api/rest/user/listing/enquiry-request', {user_id:userId})
  }

  supportRequestlistApi(userId){
    return this.apiservices.get('/api/rest/user/listing/support-request', {user_id:userId})
  }

  bookedOrderListApi(user_id){
    return this.apiservices.get('/api/rest/user/listing/booking', {user_id:user_id})
  }

  topicOrderListApi(topicListParams){
    return this.apiservices.get('/api/rest/user/listing/course-codes', topicListParams)
  }

  paymentList(user_id){
    return this.apiservices.get('/api/v1/invoice_list', {user_id:user_id})
  }

}
