import { Component, OnInit } from '@angular/core';
import { of } from 'rxjs';
import { catchError, finalize, tap } from 'rxjs/operators';
import { ProfileService } from '../../services';

@Component({
  selector: 'app-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.css']
})
export class PaymentsComponent implements OnInit {
  isLoading: boolean = false;
  paymentInfos: any;
  error: any;

  constructor(private profileServices: ProfileService) { }

  ngOnInit() {
    this.payemtDetails()
  }
//User Payment Details
  payemtDetails(){
    let userId = localStorage.getItem("user_Id");
    this.isLoading = true;
    this.profileServices
    .paymentList(userId)
    .pipe(
      tap(response => {
        this.paymentInfos = response.data;
      }),
      finalize(() => (this.isLoading = false)),
      catchError(error => of((this.error = error)))
    )
    .subscribe();
  }

}
