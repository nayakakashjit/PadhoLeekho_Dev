import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineTestSeriesComponent } from './online-test-series.component';

describe('OnlineTestSeriesComponent', () => {
  let component: OnlineTestSeriesComponent;
  let fixture: ComponentFixture<OnlineTestSeriesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineTestSeriesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineTestSeriesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
