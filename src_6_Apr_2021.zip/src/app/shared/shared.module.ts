import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TestimonialComponent, DownloadComponent } from '../shared';
import { IsloadingComponent } from './isloading/isloading.component';
import { AlertComponent } from './alert/alert.component'; 
import { FormsModule } from '@angular/forms';
import { CarouselModule } from 'ngx-owl-carousel-o';



@NgModule({
  declarations: [TestimonialComponent, DownloadComponent, IsloadingComponent, AlertComponent],
  imports: [
    CommonModule, FormsModule, CarouselModule
  ],
  exports: [TestimonialComponent, DownloadComponent, IsloadingComponent, AlertComponent]
})
export class SharedModule { }
