import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TestimonialComponent, DownloadComponent } from '../shared';
import { IsloadingComponent } from './isloading/isloading.component';
import { DetailsComponent } from './details/details.component';

@NgModule({
  declarations: [TestimonialComponent, DownloadComponent, IsloadingComponent, DetailsComponent],
  imports: [
    CommonModule
  ],
  exports: [TestimonialComponent, DownloadComponent, IsloadingComponent]
})
export class SharedModule { }
