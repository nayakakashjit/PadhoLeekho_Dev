import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompettitiveRoutingModule } from './compettitive-routing.module';
import { CatComponent } from './pages/cat/cat.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms'



@NgModule({
  declarations: [CatComponent],
  imports: [
    CommonModule,
    CompettitiveRoutingModule,
    SharedModule,
    ReactiveFormsModule
  ]
})
export class CompetitiveModule { }
