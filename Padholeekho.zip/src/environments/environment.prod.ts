export const environment = {
  production: true,
  server_url: 'https://34.69.233.188/padholeekho/public'
};
