import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TestSeriesRoutingModule } from './test-series-routing.module';
import { OnlineTestSeriesComponent } from './pages/online-test-series/online-test-series.component';

@NgModule({
  declarations: [OnlineTestSeriesComponent],
  imports: [
    CommonModule,
    TestSeriesRoutingModule
  ]
})
export class TestSeriesModule { }
