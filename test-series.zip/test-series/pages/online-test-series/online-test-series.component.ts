import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-online-test-series',
  templateUrl: './online-test-series.component.html',
  styleUrls: ['./online-test-series.component.css']
})
export class OnlineTestSeriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
